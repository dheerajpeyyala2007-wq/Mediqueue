import { Patient, PatientStatus, CaseType } from '@/types/hospital';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Clock, User, AlertCircle, CheckCircle, Stethoscope, Bell } from 'lucide-react';
import { cn } from '@/lib/utils';

interface PatientQueueProps {
  patients: Patient[];
  onCallPatient?: (patientId: string) => void;
  showActions?: boolean;
}

const getStatusBadge = (status: PatientStatus) => {
  switch (status) {
    case 'waiting':
      return { variant: 'secondary' as const, label: 'Waiting', icon: Clock };
    case 'called':
      return { variant: 'warning' as const, label: 'Called', icon: Bell };
    case 'in-treatment':
      return { variant: 'default' as const, label: 'In Treatment', icon: Stethoscope };
    case 'completed':
      return { variant: 'success' as const, label: 'Completed', icon: CheckCircle };
  }
};

export function PatientQueue({ patients, onCallPatient, showActions = false }: PatientQueueProps) {
  const emergencyPatients = patients.filter(p => p.caseType === 'emergency');
  const normalPatients = patients.filter(p => p.caseType === 'normal');

  return (
    <div className="space-y-6">
      {emergencyPatients.length > 0 && (
        <Card variant="default" className="border-emergency/30 bg-emergency/5">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-emergency">
              <AlertCircle className="w-5 h-5" />
              Emergency Queue
              <Badge variant="emergency" className="ml-2">
                {emergencyPatients.length} patients
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {emergencyPatients.map((patient, index) => (
              <PatientRow
                key={patient.id}
                patient={patient}
                index={index}
                onCall={onCallPatient}
                showActions={showActions}
              />
            ))}
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2">
            <User className="w-5 h-5 text-primary" />
            Regular Queue
            <Badge variant="secondary" className="ml-2">
              {normalPatients.length} patients
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {normalPatients.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">No patients in queue</p>
          ) : (
            normalPatients.map((patient, index) => (
              <PatientRow
                key={patient.id}
                patient={patient}
                index={emergencyPatients.length + index}
                onCall={onCallPatient}
                showActions={showActions}
              />
            ))
          )}
        </CardContent>
      </Card>
    </div>
  );
}

interface PatientRowProps {
  patient: Patient;
  index: number;
  onCall?: (patientId: string) => void;
  showActions?: boolean;
}

function PatientRow({ patient, index, onCall, showActions }: PatientRowProps) {
  const statusInfo = getStatusBadge(patient.status);
  const StatusIcon = statusInfo.icon;

  return (
    <div className={cn(
      "flex items-center gap-4 p-4 rounded-xl border transition-all duration-200",
      patient.caseType === 'emergency' 
        ? "bg-emergency/5 border-emergency/20 hover:border-emergency/40" 
        : "bg-card border-border hover:border-primary/30",
      "animate-fade-in"
    )}
    style={{ animationDelay: `${index * 50}ms` }}
    >
      {/* Queue Position */}
      <div className={cn(
        "flex items-center justify-center w-12 h-12 rounded-xl font-bold text-lg",
        patient.caseType === 'emergency' 
          ? "bg-emergency text-emergency-foreground" 
          : "bg-primary/10 text-primary"
      )}>
        {patient.tokenNumber}
      </div>

      {/* Patient Info */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <h4 className="font-semibold text-foreground truncate">{patient.name}</h4>
          {patient.caseType === 'emergency' && (
            <Badge variant="emergency" className="text-xs">🔴 Emergency</Badge>
          )}
        </div>
        <div className="flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
          <span className="flex items-center gap-1">
            <Stethoscope className="w-3.5 h-3.5" />
            {patient.specialization}
          </span>
          <span>•</span>
          <span className="flex items-center gap-1">
            <Clock className="w-3.5 h-3.5" />
            ~{patient.estimatedWaitTime} min
          </span>
        </div>
      </div>

      {/* Status */}
      <Badge variant={statusInfo.variant} className="flex items-center gap-1">
        <StatusIcon className="w-3.5 h-3.5" />
        {statusInfo.label}
      </Badge>

      {/* Actions */}
      {showActions && patient.status === 'waiting' && onCall && (
        <Button
          size="sm"
          variant={patient.caseType === 'emergency' ? 'emergency' : 'default'}
          onClick={() => onCall(patient.id)}
        >
          Call Next
        </Button>
      )}
    </div>
  );
}

interface PatientTokenDisplayProps {
  tokenNumber: string;
  position: number;
  estimatedTime: number;
  status: PatientStatus;
}

export function PatientTokenDisplay({ tokenNumber, position, estimatedTime, status }: PatientTokenDisplayProps) {
  return (
    <Card variant="elevated" className="text-center overflow-hidden">
      <div className="bg-primary/10 py-6">
        <p className="text-sm font-medium text-muted-foreground mb-2">Your Token Number</p>
        <p className="text-5xl font-bold text-primary">{tokenNumber}</p>
      </div>
      <CardContent className="py-6 space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-muted-foreground">Queue Position</p>
            <p className="text-2xl font-bold text-foreground">#{position}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Est. Wait Time</p>
            <p className="text-2xl font-bold text-foreground">{estimatedTime}m</p>
          </div>
        </div>
        <Badge variant={getStatusBadge(status).variant} className="text-sm px-4 py-1.5">
          {getStatusBadge(status).label}
        </Badge>
      </CardContent>
    </Card>
  );
}
