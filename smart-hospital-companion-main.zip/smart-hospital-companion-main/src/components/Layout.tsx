import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { 
  Home, 
  Building2, 
  User, 
  Stethoscope, 
  ClipboardList, 
  BarChart3, 
  ArrowLeft,
  Menu,
  X 
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useState } from 'react';

interface NavItem {
  path: string;
  label: string;
  icon: React.ReactNode;
}

const navItems: NavItem[] = [
  { path: '/', label: 'Find Hospital', icon: <Home className="w-5 h-5" /> },
];

const dashboardItems: NavItem[] = [
  { path: '/hospital', label: 'Hospital', icon: <Building2 className="w-5 h-5" /> },
  { path: '/patient', label: 'Patient', icon: <User className="w-5 h-5" /> },
  { path: '/doctor', label: 'Doctor', icon: <Stethoscope className="w-5 h-5" /> },
  { path: '/reception', label: 'Reception', icon: <ClipboardList className="w-5 h-5" /> },
  { path: '/admin', label: 'Admin', icon: <BarChart3 className="w-5 h-5" /> },
];

export function Header() {
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const isHome = location.pathname === '/';
  const isDashboard = !isHome;

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 group">
            <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center shadow-md group-hover:shadow-lg transition-shadow">
              <span className="text-xl">🏥</span>
            </div>
            <div className="hidden sm:block">
              <h1 className="text-lg font-bold text-foreground">MediQueue</h1>
              <p className="text-xs text-muted-foreground -mt-0.5">Smart Hospital Queue</p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-1">
            {isDashboard && (
              <>
                <Link to="/">
                  <Button variant="ghost" size="sm" className="gap-1.5">
                    <ArrowLeft className="w-4 h-4" />
                    Home
                  </Button>
                </Link>
                <div className="w-px h-6 bg-border mx-2" />
              </>
            )}
            
            {isDashboard && dashboardItems.map((item) => (
              <Link key={item.path} to={item.path}>
                <Button
                  variant={location.pathname === item.path ? 'default' : 'ghost'}
                  size="sm"
                  className="gap-1.5"
                >
                  {item.icon}
                  {item.label}
                </Button>
              </Link>
            ))}
          </nav>

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </Button>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <nav className="md:hidden py-4 border-t border-border animate-fade-in">
            <div className="flex flex-col gap-1">
              {isDashboard && (
                <Link to="/" onClick={() => setMobileMenuOpen(false)}>
                  <Button variant="ghost" className="w-full justify-start gap-2">
                    <ArrowLeft className="w-4 h-4" />
                    Back to Home
                  </Button>
                </Link>
              )}
              
              {isDashboard && dashboardItems.map((item) => (
                <Link key={item.path} to={item.path} onClick={() => setMobileMenuOpen(false)}>
                  <Button
                    variant={location.pathname === item.path ? 'secondary' : 'ghost'}
                    className="w-full justify-start gap-2"
                  >
                    {item.icon}
                    {item.label} Dashboard
                  </Button>
                </Link>
              ))}
            </div>
          </nav>
        )}
      </div>
    </header>
  );
}

export function PageHeader({ 
  title, 
  description, 
  icon, 
  actions 
}: { 
  title: string; 
  description?: string; 
  icon?: React.ReactNode;
  actions?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
      <div className="flex items-center gap-3">
        {icon && (
          <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
            {icon}
          </div>
        )}
        <div>
          <h1 className="text-2xl font-bold text-foreground">{title}</h1>
          {description && (
            <p className="text-muted-foreground">{description}</p>
          )}
        </div>
      </div>
      {actions && <div className="flex items-center gap-2">{actions}</div>}
    </div>
  );
}
