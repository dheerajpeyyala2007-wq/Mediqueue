import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';
import { TrendingUp, Users, Clock, AlertTriangle, Calendar, Activity } from 'lucide-react';

const hourlyData = [
  { hour: '6AM', patients: 12 },
  { hour: '8AM', patients: 45 },
  { hour: '10AM', patients: 78 },
  { hour: '12PM', patients: 65 },
  { hour: '2PM', patients: 82 },
  { hour: '4PM', patients: 58 },
  { hour: '6PM', patients: 42 },
  { hour: '8PM', patients: 28 },
];

const caseTypeData = [
  { name: 'Emergency', value: 15, color: 'hsl(var(--emergency))' },
  { name: 'Normal', value: 85, color: 'hsl(var(--primary))' },
];

const doctorUtilization = [
  { name: 'Dr. Kapoor', patients: 18, capacity: 25 },
  { name: 'Dr. Mehta', patients: 22, capacity: 25 },
  { name: 'Dr. Reddy', patients: 12, capacity: 25 },
  { name: 'Dr. Shah', patients: 16, capacity: 25 },
  { name: 'Dr. Joshi', patients: 20, capacity: 25 },
];

const weeklyTrend = [
  { day: 'Mon', patients: 145, waitTime: 28 },
  { day: 'Tue', patients: 132, waitTime: 24 },
  { day: 'Wed', patients: 156, waitTime: 32 },
  { day: 'Thu', patients: 142, waitTime: 26 },
  { day: 'Fri', patients: 168, waitTime: 35 },
  { day: 'Sat', patients: 98, waitTime: 18 },
  { day: 'Sun', patients: 72, waitTime: 15 },
];

interface AdminStatsProps {
  stats: {
    totalPatients: number;
    avgWaitTime: number;
    emergencyRatio: number;
    doctorUtilization: number;
  };
}

export function AdminStats({ stats }: AdminStatsProps) {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      <StatCard
        title="Total Patients Today"
        value={stats.totalPatients}
        icon={<Users className="w-5 h-5" />}
        change="+12%"
        positive
      />
      <StatCard
        title="Avg. Wait Time"
        value={`${stats.avgWaitTime}m`}
        icon={<Clock className="w-5 h-5" />}
        change="-8%"
        positive
      />
      <StatCard
        title="Emergency Cases"
        value={`${stats.emergencyRatio}%`}
        icon={<AlertTriangle className="w-5 h-5" />}
        change="+2%"
        positive={false}
      />
      <StatCard
        title="Doctor Utilization"
        value={`${stats.doctorUtilization}%`}
        icon={<Activity className="w-5 h-5" />}
        change="+5%"
        positive
      />
    </div>
  );
}

interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  change: string;
  positive: boolean;
}

function StatCard({ title, value, icon, change, positive }: StatCardProps) {
  return (
    <Card variant="stat">
      <CardContent className="p-5">
        <div className="flex items-start justify-between mb-3">
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
            {icon}
          </div>
          <Badge variant={positive ? 'crowdLow' : 'crowdHigh'} className="text-xs">
            {change}
          </Badge>
        </div>
        <p className="text-2xl font-bold text-foreground">{value}</p>
        <p className="text-sm text-muted-foreground">{title}</p>
      </CardContent>
    </Card>
  );
}

export function HourlyPatientChart() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-primary" />
          Peak Hour Analysis
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={hourlyData}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
              <XAxis dataKey="hour" className="text-xs" />
              <YAxis className="text-xs" />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px',
                }}
              />
              <Bar
                dataKey="patients"
                fill="hsl(var(--primary))"
                radius={[4, 4, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}

export function CaseTypeDistribution() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-primary" />
          Case Distribution
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[200px] flex items-center justify-center">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={caseTypeData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={5}
                dataKey="value"
              >
                {caseTypeData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px',
                }}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="flex justify-center gap-6 mt-4">
          {caseTypeData.map((item) => (
            <div key={item.name} className="flex items-center gap-2">
              <div
                className="w-3 h-3 rounded-full"
                style={{ backgroundColor: item.color }}
              />
              <span className="text-sm text-muted-foreground">
                {item.name}: {item.value}%
              </span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

export function DoctorUtilizationChart() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Users className="w-5 h-5 text-primary" />
          Doctor Utilization
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {doctorUtilization.map((doctor) => {
            const percentage = (doctor.patients / doctor.capacity) * 100;
            const isOverloaded = percentage > 80;
            
            return (
              <div key={doctor.name} className="space-y-1">
                <div className="flex items-center justify-between text-sm">
                  <span className="font-medium">{doctor.name}</span>
                  <span className={isOverloaded ? 'text-emergency' : 'text-muted-foreground'}>
                    {doctor.patients}/{doctor.capacity} patients
                  </span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all ${
                      isOverloaded ? 'bg-emergency' : 'bg-primary'
                    }`}
                    style={{ width: `${percentage}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}

export function WeeklyTrendChart() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="w-5 h-5 text-primary" />
          Weekly Trend
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[250px]">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={weeklyTrend}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
              <XAxis dataKey="day" className="text-xs" />
              <YAxis yAxisId="left" className="text-xs" />
              <YAxis yAxisId="right" orientation="right" className="text-xs" />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px',
                }}
              />
              <Line
                yAxisId="left"
                type="monotone"
                dataKey="patients"
                stroke="hsl(var(--primary))"
                strokeWidth={2}
                dot={{ fill: 'hsl(var(--primary))' }}
              />
              <Line
                yAxisId="right"
                type="monotone"
                dataKey="waitTime"
                stroke="hsl(var(--warning))"
                strokeWidth={2}
                dot={{ fill: 'hsl(var(--warning))' }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="flex justify-center gap-6 mt-4">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-primary" />
            <span className="text-sm text-muted-foreground">Patients</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-warning" />
            <span className="text-sm text-muted-foreground">Wait Time (min)</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
