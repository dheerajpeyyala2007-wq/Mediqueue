import { Hospital, CrowdLevel } from '@/types/hospital';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MapPin, Clock, Users, AlertCircle, Star, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';

interface HospitalCardProps {
  hospital: Hospital;
  onClick: () => void;
}

const getCrowdBadgeVariant = (level: CrowdLevel) => {
  switch (level) {
    case 'low':
      return 'crowdLow';
    case 'medium':
      return 'crowdMedium';
    case 'high':
      return 'crowdHigh';
  }
};

const getCrowdLabel = (level: CrowdLevel) => {
  switch (level) {
    case 'low':
      return 'Low Crowd';
    case 'medium':
      return 'Medium Crowd';
    case 'high':
      return 'High Crowd';
  }
};

export function HospitalCard({ hospital, onClick }: HospitalCardProps) {
  return (
    <Card
      variant="elevated"
      className="cursor-pointer group hover:border-primary/30 transition-all duration-300 animate-fade-in"
      onClick={onClick}
    >
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-2">
              <Badge variant={hospital.type === 'public' ? 'secondary' : 'default'}>
                {hospital.type === 'public' ? 'Public' : 'Private'}
              </Badge>
              {hospital.emergencyAvailable && (
                <Badge variant="emergency" className="gap-1">
                  <AlertCircle className="w-3 h-3" />
                  24/7
                </Badge>
              )}
            </div>
            
            <h3 className="text-lg font-semibold text-foreground mb-1 truncate group-hover:text-primary transition-colors">
              {hospital.name}
            </h3>
            
            <div className="flex items-center gap-1 text-muted-foreground text-sm mb-3">
              <MapPin className="w-3.5 h-3.5" />
              <span>{hospital.distance} km away</span>
              <span className="mx-1">•</span>
              <Star className="w-3.5 h-3.5 text-warning fill-warning" />
              <span>{hospital.rating}</span>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <Badge variant={getCrowdBadgeVariant(hospital.crowdLevel)}>
                <Users className="w-3 h-3 mr-1" />
                {getCrowdLabel(hospital.crowdLevel)}
              </Badge>
              
              <div className="flex items-center gap-1.5 text-sm">
                <Clock className={cn(
                  "w-4 h-4",
                  hospital.averageWaitTime > 40 ? "text-emergency" :
                  hospital.averageWaitTime > 25 ? "text-warning" :
                  "text-success"
                )} />
                <span className="font-medium">~{hospital.averageWaitTime} min wait</span>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary/10 group-hover:bg-primary/20 transition-colors">
            <ChevronRight className="w-5 h-5 text-primary" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
