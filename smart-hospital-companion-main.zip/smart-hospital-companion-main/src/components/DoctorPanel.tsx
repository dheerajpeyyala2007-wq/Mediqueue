import { Doctor, DoctorStatus } from '@/types/hospital';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { User, Users, CheckCircle, XCircle, Clock, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';

interface DoctorPanelProps {
  doctors: Doctor[];
  onCallNext?: (doctorId: string) => void;
  isDoctor?: boolean;
}

const getStatusInfo = (status: DoctorStatus) => {
  switch (status) {
    case 'available':
      return { color: 'bg-success', label: 'Available', textColor: 'text-success' };
    case 'busy':
      return { color: 'bg-emergency', label: 'With Patient', textColor: 'text-emergency' };
    case 'offline':
      return { color: 'bg-muted-foreground', label: 'Offline', textColor: 'text-muted-foreground' };
  }
};

export function DoctorPanel({ doctors, onCallNext, isDoctor = false }: DoctorPanelProps) {
  const availableDoctors = doctors.filter(d => d.status === 'available');
  const busyDoctors = doctors.filter(d => d.status === 'busy');
  const offlineDoctors = doctors.filter(d => d.status === 'offline');

  return (
    <div className="space-y-4">
      {/* Summary Stats */}
      <div className="grid grid-cols-3 gap-3">
        <Card variant="stat" className="text-center">
          <CardContent className="py-4">
            <div className="flex items-center justify-center gap-2 mb-1">
              <div className="w-3 h-3 rounded-full bg-success animate-pulse" />
              <span className="text-sm font-medium text-muted-foreground">Available</span>
            </div>
            <p className="text-2xl font-bold text-success">{availableDoctors.length}</p>
          </CardContent>
        </Card>
        <Card variant="stat" className="text-center">
          <CardContent className="py-4">
            <div className="flex items-center justify-center gap-2 mb-1">
              <div className="w-3 h-3 rounded-full bg-emergency" />
              <span className="text-sm font-medium text-muted-foreground">Busy</span>
            </div>
            <p className="text-2xl font-bold text-emergency">{busyDoctors.length}</p>
          </CardContent>
        </Card>
        <Card variant="stat" className="text-center">
          <CardContent className="py-4">
            <div className="flex items-center justify-center gap-2 mb-1">
              <div className="w-3 h-3 rounded-full bg-muted-foreground" />
              <span className="text-sm font-medium text-muted-foreground">Offline</span>
            </div>
            <p className="text-2xl font-bold text-muted-foreground">{offlineDoctors.length}</p>
          </CardContent>
        </Card>
      </div>

      {/* Doctor List */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2">
            <Users className="w-5 h-5 text-primary" />
            Medical Staff
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {doctors.map((doctor, index) => (
            <DoctorRow
              key={doctor.id}
              doctor={doctor}
              index={index}
              onCallNext={onCallNext}
              isDoctor={isDoctor}
            />
          ))}
        </CardContent>
      </Card>
    </div>
  );
}

interface DoctorRowProps {
  doctor: Doctor;
  index: number;
  onCallNext?: (doctorId: string) => void;
  isDoctor?: boolean;
}

function DoctorRow({ doctor, index, onCallNext, isDoctor }: DoctorRowProps) {
  const statusInfo = getStatusInfo(doctor.status);

  return (
    <div
      className={cn(
        "flex items-center gap-4 p-4 rounded-xl border transition-all duration-200",
        doctor.status === 'available' 
          ? "bg-success/5 border-success/20 hover:border-success/40" 
          : "bg-card border-border hover:border-primary/30",
        "animate-fade-in"
      )}
      style={{ animationDelay: `${index * 50}ms` }}
    >
      {/* Avatar */}
      <div className="relative">
        <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
          <User className="w-6 h-6 text-primary" />
        </div>
        <div className={cn(
          "absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full border-2 border-card",
          statusInfo.color
        )} />
      </div>

      {/* Doctor Info */}
      <div className="flex-1 min-w-0">
        <h4 className="font-semibold text-foreground truncate">{doctor.name}</h4>
        <p className="text-sm text-muted-foreground">{doctor.specialization}</p>
      </div>

      {/* Stats */}
      <div className="text-right hidden sm:block">
        <p className="text-sm font-medium text-foreground">
          {doctor.patientsAssigned} in queue
        </p>
        <p className="text-xs text-muted-foreground">
          {doctor.patientsToday} seen today
        </p>
      </div>

      {/* Status Badge */}
      <Badge
        variant={doctor.status === 'available' ? 'success' : doctor.status === 'busy' ? 'warning' : 'secondary'}
        className="hidden md:flex"
      >
        {statusInfo.label}
      </Badge>

      {/* Call Next Button (for doctor view) */}
      {isDoctor && doctor.status === 'available' && doctor.patientsAssigned > 0 && onCallNext && (
        <Button
          size="sm"
          variant="success"
          onClick={() => onCallNext(doctor.id)}
          className="gap-1"
        >
          Call Next
          <ChevronRight className="w-4 h-4" />
        </Button>
      )}
    </div>
  );
}

interface DoctorDashboardCardProps {
  doctor: Doctor;
  nextPatient?: { name: string; caseType: 'emergency' | 'normal'; specialization: string };
  onCallNext: () => void;
}

export function DoctorDashboardCard({ doctor, nextPatient, onCallNext }: DoctorDashboardCardProps) {
  const statusInfo = getStatusInfo(doctor.status);

  return (
    <Card variant="elevated" className="overflow-hidden">
      <div className={cn(
        "px-6 py-4",
        doctor.status === 'available' ? "bg-success/10" : "bg-muted"
      )}>
        <div className="flex items-center gap-4">
          <div className="relative">
            <div className="w-16 h-16 rounded-full bg-card flex items-center justify-center shadow-md">
              <User className="w-8 h-8 text-primary" />
            </div>
            <div className={cn(
              "absolute -bottom-1 -right-1 w-5 h-5 rounded-full border-2 border-card",
              statusInfo.color
            )} />
          </div>
          <div>
            <h3 className="text-xl font-bold text-foreground">{doctor.name}</h3>
            <p className="text-muted-foreground">{doctor.specialization}</p>
          </div>
        </div>
      </div>

      <CardContent className="py-6 space-y-6">
        <div className="grid grid-cols-2 gap-4 text-center">
          <div className="p-4 rounded-xl bg-muted/50">
            <p className="text-sm text-muted-foreground mb-1">Patients in Queue</p>
            <p className="text-3xl font-bold text-foreground">{doctor.patientsAssigned}</p>
          </div>
          <div className="p-4 rounded-xl bg-muted/50">
            <p className="text-sm text-muted-foreground mb-1">Seen Today</p>
            <p className="text-3xl font-bold text-foreground">{doctor.patientsToday}</p>
          </div>
        </div>

        {nextPatient && doctor.status === 'available' && (
          <div className="p-4 rounded-xl border border-primary/20 bg-primary/5">
            <p className="text-sm font-medium text-primary mb-2">Next Patient</p>
            <div className="flex items-center justify-between">
              <div>
                <p className="font-semibold text-foreground">{nextPatient.name}</p>
                <p className="text-sm text-muted-foreground">{nextPatient.specialization}</p>
              </div>
              {nextPatient.caseType === 'emergency' && (
                <Badge variant="emergency">Emergency</Badge>
              )}
            </div>
          </div>
        )}

        <Button
          className="w-full"
          size="lg"
          variant={doctor.status === 'available' ? 'hero' : 'secondary'}
          disabled={doctor.status !== 'available' || doctor.patientsAssigned === 0}
          onClick={onCallNext}
        >
          {doctor.status === 'available' 
            ? (doctor.patientsAssigned > 0 ? 'Call Next Patient' : 'No Patients in Queue')
            : 'Currently With Patient'}
        </Button>
      </CardContent>
    </Card>
  );
}
