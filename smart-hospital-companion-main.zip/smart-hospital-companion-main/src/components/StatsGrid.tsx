import { HospitalStats } from '@/types/hospital';
import { Card, CardContent } from '@/components/ui/card';
import { Users, Stethoscope, AlertTriangle, Clock, Activity } from 'lucide-react';
import { cn } from '@/lib/utils';

interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  trend?: 'up' | 'down' | 'neutral';
  description?: string;
  variant?: 'default' | 'success' | 'warning' | 'emergency';
}

function StatCard({ title, value, icon, description, variant = 'default' }: StatCardProps) {
  const variantStyles = {
    default: 'bg-primary/10 text-primary',
    success: 'bg-success/10 text-success',
    warning: 'bg-warning/10 text-warning',
    emergency: 'bg-emergency/10 text-emergency',
  };

  return (
    <Card variant="stat" className="overflow-hidden">
      <CardContent className="p-5">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <p className="text-sm font-medium text-muted-foreground mb-1">{title}</p>
            <p className="text-3xl font-bold text-foreground">{value}</p>
            {description && (
              <p className="text-xs text-muted-foreground mt-1">{description}</p>
            )}
          </div>
          <div className={cn(
            "w-12 h-12 rounded-xl flex items-center justify-center",
            variantStyles[variant]
          )}>
            {icon}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

interface StatsGridProps {
  stats: HospitalStats;
}

export function StatsGrid({ stats }: StatsGridProps) {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      <StatCard
        title="Patients Waiting"
        value={stats.totalWaiting}
        icon={<Users className="w-6 h-6" />}
        description={`${stats.totalPatients} total today`}
        variant="default"
      />
      <StatCard
        title="Doctors Available"
        value={stats.doctorsAvailable}
        icon={<Stethoscope className="w-6 h-6" />}
        description="On duty now"
        variant="success"
      />
      <StatCard
        title="Emergency Cases"
        value={stats.emergencyCases}
        icon={<AlertTriangle className="w-6 h-6" />}
        description="Priority queue"
        variant="emergency"
      />
      <StatCard
        title="Avg. Wait Time"
        value={`${stats.averageWaitTime}m`}
        icon={<Clock className="w-6 h-6" />}
        description={stats.queueStatus === 'normal' ? 'Normal load' : 'High load'}
        variant={stats.averageWaitTime > 30 ? 'warning' : 'success'}
      />
    </div>
  );
}

export function QueueStatusBanner({ status }: { status: 'normal' | 'overloaded' }) {
  return (
    <div className={cn(
      "flex items-center gap-3 px-4 py-3 rounded-xl",
      status === 'normal' 
        ? "bg-success/10 border border-success/20" 
        : "bg-emergency/10 border border-emergency/20"
    )}>
      <Activity className={cn(
        "w-5 h-5",
        status === 'normal' ? "text-success" : "text-emergency"
      )} />
      <div>
        <p className={cn(
          "font-semibold",
          status === 'normal' ? "text-success" : "text-emergency"
        )}>
          {status === 'normal' ? 'Queue Status: Normal' : 'Queue Status: Overloaded'}
        </p>
        <p className="text-sm text-muted-foreground">
          {status === 'normal' 
            ? 'All systems operating smoothly' 
            : 'High patient volume - additional staff recommended'}
        </p>
      </div>
    </div>
  );
}
