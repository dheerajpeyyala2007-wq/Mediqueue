import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { UserPlus, AlertCircle, CheckCircle } from 'lucide-react';
import { SPECIALIZATIONS } from '@/types/hospital';
import { toast } from 'sonner';

interface ReceptionCheckInProps {
  onCheckIn: (patientData: {
    name: string;
    caseType: 'emergency' | 'normal';
    specialization: string;
  }) => void;
}

export function ReceptionCheckIn({ onCheckIn }: ReceptionCheckInProps) {
  const [name, setName] = useState('');
  const [caseType, setCaseType] = useState<'emergency' | 'normal'>('normal');
  const [specialization, setSpecialization] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name.trim()) {
      toast.error('Please enter patient name');
      return;
    }
    
    if (!specialization) {
      toast.error('Please select specialization');
      return;
    }

    onCheckIn({
      name: name.trim(),
      caseType,
      specialization,
    });

    // Generate token number
    const tokenPrefix = caseType === 'emergency' ? 'E' : 'N';
    const tokenNumber = `${tokenPrefix}${String(Math.floor(Math.random() * 999) + 1).padStart(3, '0')}`;
    
    toast.success(
      <div className="flex flex-col gap-1">
        <span className="font-semibold">Patient Registered Successfully!</span>
        <span className="text-sm">Token: {tokenNumber}</span>
      </div>
    );

    // Reset form
    setName('');
    setCaseType('normal');
    setSpecialization('');
  };

  return (
    <Card variant="elevated">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <UserPlus className="w-5 h-5 text-primary" />
          Patient Check-In
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Patient Name */}
          <div className="space-y-2">
            <Label htmlFor="patient-name">Patient Name</Label>
            <Input
              id="patient-name"
              placeholder="Enter patient name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>

          {/* Case Type */}
          <div className="space-y-2">
            <Label>Case Type</Label>
            <div className="grid grid-cols-2 gap-3">
              <Button
                type="button"
                variant={caseType === 'normal' ? 'default' : 'outline'}
                className="h-auto py-4 flex flex-col gap-1"
                onClick={() => setCaseType('normal')}
              >
                <CheckCircle className="w-5 h-5" />
                <span>Normal</span>
                <span className="text-xs font-normal opacity-80">Regular queue</span>
              </Button>
              <Button
                type="button"
                variant={caseType === 'emergency' ? 'emergency' : 'outline'}
                className="h-auto py-4 flex flex-col gap-1"
                onClick={() => setCaseType('emergency')}
              >
                <AlertCircle className="w-5 h-5" />
                <span>Emergency</span>
                <span className="text-xs font-normal opacity-80">Priority queue</span>
              </Button>
            </div>
          </div>

          {/* Specialization */}
          <div className="space-y-2">
            <Label htmlFor="specialization">Required Specialization</Label>
            <Select value={specialization} onValueChange={setSpecialization}>
              <SelectTrigger>
                <SelectValue placeholder="Select department" />
              </SelectTrigger>
              <SelectContent>
                {SPECIALIZATIONS.map((spec) => (
                  <SelectItem key={spec.id} value={spec.name}>
                    <span className="flex items-center gap-2">
                      <span>{spec.icon}</span>
                      <span>{spec.name}</span>
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Submit Button */}
          <Button type="submit" className="w-full" size="lg" variant="hero">
            <UserPlus className="w-5 h-5" />
            Register Patient
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}

interface QueueSummaryProps {
  emergencyCount: number;
  normalCount: number;
}

export function QueueSummary({ emergencyCount, normalCount }: QueueSummaryProps) {
  return (
    <div className="grid grid-cols-2 gap-4">
      <Card className="border-emergency/30 bg-emergency/5">
        <CardContent className="py-6 text-center">
          <Badge variant="emergency" className="mb-3">Emergency Queue</Badge>
          <p className="text-4xl font-bold text-emergency">{emergencyCount}</p>
          <p className="text-sm text-muted-foreground mt-1">patients waiting</p>
        </CardContent>
      </Card>
      <Card className="border-primary/30 bg-primary/5">
        <CardContent className="py-6 text-center">
          <Badge variant="default" className="mb-3">Normal Queue</Badge>
          <p className="text-4xl font-bold text-primary">{normalCount}</p>
          <p className="text-sm text-muted-foreground mt-1">patients waiting</p>
        </CardContent>
      </Card>
    </div>
  );
}
