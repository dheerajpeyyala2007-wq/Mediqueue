export type HospitalType = 'public' | 'private';
export type CrowdLevel = 'low' | 'medium' | 'high';
export type PatientStatus = 'waiting' | 'called' | 'in-treatment' | 'completed';
export type CaseType = 'emergency' | 'normal';
export type DoctorStatus = 'available' | 'busy' | 'offline';
export type QueueStatus = 'normal' | 'overloaded';

export interface Hospital {
  id: string;
  name: string;
  type: HospitalType;
  distance: number;
  crowdLevel: CrowdLevel;
  averageWaitTime: number;
  emergencyAvailable: boolean;
  address: string;
  rating: number;
  totalBeds: number;
  availableBeds: number;
}

export interface Patient {
  id: string;
  name: string;
  caseType: CaseType;
  specialization: string;
  estimatedWaitTime: number;
  queuePosition: number;
  status: PatientStatus;
  checkInTime: Date;
  tokenNumber: string;
}

export interface Doctor {
  id: string;
  name: string;
  specialization: string;
  status: DoctorStatus;
  patientsAssigned: number;
  patientsToday: number;
  avatar?: string;
}

export interface HospitalStats {
  totalWaiting: number;
  doctorsAvailable: number;
  emergencyCases: number;
  averageWaitTime: number;
  queueStatus: QueueStatus;
  totalPatients: number;
}

export interface Specialization {
  id: string;
  name: string;
  icon: string;
}

export const SPECIALIZATIONS: Specialization[] = [
  { id: 'general', name: 'General Medicine', icon: '🩺' },
  { id: 'cardiology', name: 'Cardiology', icon: '❤️' },
  { id: 'orthopedics', name: 'Orthopedics', icon: '🦴' },
  { id: 'pediatrics', name: 'Pediatrics', icon: '👶' },
  { id: 'neurology', name: 'Neurology', icon: '🧠' },
  { id: 'dermatology', name: 'Dermatology', icon: '🧴' },
  { id: 'ophthalmology', name: 'Ophthalmology', icon: '👁️' },
  { id: 'ent', name: 'ENT', icon: '👂' },
];
