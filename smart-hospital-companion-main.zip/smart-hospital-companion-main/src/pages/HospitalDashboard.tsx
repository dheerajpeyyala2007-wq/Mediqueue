import { useSearchParams, Link } from 'react-router-dom';
import { Header, PageHeader } from '@/components/Layout';
import { StatsGrid, QueueStatusBanner } from '@/components/StatsGrid';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { mockHospitals, mockHospitalStats } from '@/data/mockData';
import { Building2, User, Stethoscope, ClipboardList, BarChart3, MapPin, Star } from 'lucide-react';

export default function HospitalDashboard() {
  const [searchParams] = useSearchParams();
  const hospitalId = searchParams.get('id') || '1';
  const hospital = mockHospitals.find(h => h.id === hospitalId) || mockHospitals[0];

  const dashboardLinks = [
    {
      path: '/patient',
      label: 'Patient Dashboard',
      description: 'Track queue position & wait time',
      icon: <User className="w-6 h-6" />,
      color: 'bg-primary/10 text-primary',
    },
    {
      path: '/doctor',
      label: 'Doctor Dashboard',
      description: 'Manage patients & call next',
      icon: <Stethoscope className="w-6 h-6" />,
      color: 'bg-success/10 text-success',
    },
    {
      path: '/reception',
      label: 'Reception Dashboard',
      description: 'Patient check-in & registration',
      icon: <ClipboardList className="w-6 h-6" />,
      color: 'bg-warning/10 text-warning',
    },
    {
      path: '/admin',
      label: 'Admin Dashboard',
      description: 'Analytics & hospital management',
      icon: <BarChart3 className="w-6 h-6" />,
      color: 'bg-accent-foreground/10 text-accent-foreground',
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-6">
        {/* Hospital Info */}
        <Card variant="glass" className="mb-6 overflow-hidden">
          <div className="bg-primary/5 p-6 border-b border-border/50">
            <div className="flex flex-col sm:flex-row sm:items-center gap-4">
              <div className="w-16 h-16 rounded-2xl bg-primary flex items-center justify-center shadow-lg">
                <Building2 className="w-8 h-8 text-primary-foreground" />
              </div>
              <div className="flex-1">
                <h1 className="text-2xl font-bold text-foreground">{hospital.name}</h1>
                <div className="flex flex-wrap items-center gap-3 mt-1 text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <MapPin className="w-4 h-4" />
                    {hospital.address}
                  </span>
                  <span className="flex items-center gap-1">
                    <Star className="w-4 h-4 text-warning fill-warning" />
                    {hospital.rating}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* Queue Status Banner */}
        <div className="mb-6">
          <QueueStatusBanner status={mockHospitalStats.queueStatus} />
        </div>

        {/* Stats Grid */}
        <div className="mb-8">
          <h2 className="text-lg font-semibold text-foreground mb-4">Real-time Statistics</h2>
          <StatsGrid stats={mockHospitalStats} />
        </div>

        {/* Dashboard Links */}
        <div>
          <h2 className="text-lg font-semibold text-foreground mb-4">Role-based Dashboards</h2>
          <div className="grid sm:grid-cols-2 gap-4">
            {dashboardLinks.map((item) => (
              <Link key={item.path} to={item.path}>
                <Card variant="elevated" className="h-full hover:border-primary/30 transition-all duration-300 group cursor-pointer">
                  <CardContent className="p-5 flex items-center gap-4">
                    <div className={`w-14 h-14 rounded-xl flex items-center justify-center ${item.color} group-hover:scale-110 transition-transform`}>
                      {item.icon}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors">
                        {item.label}
                      </h3>
                      <p className="text-sm text-muted-foreground">{item.description}</p>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
