import { useState } from 'react';
import { Header, PageHeader } from '@/components/Layout';
import { PatientQueue, PatientTokenDisplay } from '@/components/PatientQueue';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { mockPatients } from '@/data/mockData';
import { User, Bell, RefreshCw, Sparkles } from 'lucide-react';
import { toast } from 'sonner';

export default function PatientDashboard() {
  const [patients, setPatients] = useState(mockPatients);
  
  // Simulate current patient view
  const currentPatient = patients.find(p => p.id === '2'); // Priya Patel as current user

  const handleRefresh = () => {
    toast.success('Queue updated');
    // Simulate queue update
    setPatients(prev => prev.map(p => ({
      ...p,
      estimatedWaitTime: Math.max(5, p.estimatedWaitTime - Math.floor(Math.random() * 5)),
    })));
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-6">
        <PageHeader
          title="Patient Dashboard"
          description="Track your queue position in real-time"
          icon={<User className="w-6 h-6" />}
          actions={
            <Button variant="outline" size="sm" onClick={handleRefresh}>
              <RefreshCw className="w-4 h-4 mr-1" />
              Refresh
            </Button>
          }
        />

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Current Patient Token */}
          <div className="lg:col-span-1 space-y-4">
            {currentPatient && (
              <>
                <PatientTokenDisplay
                  tokenNumber={currentPatient.tokenNumber}
                  position={currentPatient.queuePosition}
                  estimatedTime={currentPatient.estimatedWaitTime}
                  status={currentPatient.status}
                />

                {/* Notification Settings */}
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <Bell className="w-5 h-5 text-primary" />
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-foreground">Notifications Enabled</p>
                        <p className="text-sm text-muted-foreground">We'll alert you when called</p>
                      </div>
                      <Badge variant="success">Active</Badge>
                    </div>
                  </CardContent>
                </Card>

                {/* AI Insight */}
                <Card className="border-primary/30 bg-primary/5">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                        <Sparkles className="w-4 h-4 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium text-primary text-sm">AI Prediction</p>
                        <p className="text-sm text-muted-foreground mt-1">
                          Based on current flow, you may be called 5 minutes earlier than estimated. 
                          Stay nearby!
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </>
            )}
          </div>

          {/* Live Queue */}
          <div className="lg:col-span-2">
            <h2 className="text-lg font-semibold text-foreground mb-4">Live Queue</h2>
            <PatientQueue patients={patients} />
          </div>
        </div>
      </main>
    </div>
  );
}
