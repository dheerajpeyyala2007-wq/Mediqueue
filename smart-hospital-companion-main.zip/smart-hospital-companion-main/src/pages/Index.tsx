import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { HospitalCard } from '@/components/HospitalCard';
import { mockHospitals } from '@/data/mockData';
import { HospitalType } from '@/types/hospital';
import { 
  MapPin, 
  Search, 
  Building2, 
  Building, 
  Sparkles,
  Clock,
  Users,
  Shield,
  Zap
} from 'lucide-react';

const Index = () => {
  const navigate = useNavigate();
  const [location, setLocation] = useState('');
  const [hospitalType, setHospitalType] = useState<HospitalType | 'all'>('all');
  const [showResults, setShowResults] = useState(false);

  const filteredHospitals = mockHospitals.filter(hospital => {
    if (hospitalType === 'all') return true;
    return hospital.type === hospitalType;
  });

  const handleSearch = () => {
    setShowResults(true);
  };

  const handleHospitalClick = (hospitalId: string) => {
    navigate(`/hospital?id=${hospitalId}`);
  };

  const handleGetLocation = () => {
    setLocation('Detecting location...');
    // Simulate GPS detection
    setTimeout(() => {
      setLocation('Mumbai, Maharashtra');
      setShowResults(true);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        {/* Background gradient */}
        <div className="absolute inset-0 bg-gradient-to-b from-primary/5 via-background to-background" />
        
        {/* Decorative elements */}
        <div className="absolute top-20 left-10 w-72 h-72 bg-primary/10 rounded-full blur-3xl" />
        <div className="absolute top-40 right-10 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />

        <div className="relative container mx-auto px-4 pt-12 pb-16">
          {/* Header */}
          <div className="flex items-center justify-between mb-12">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-primary flex items-center justify-center shadow-lg animate-pulse-glow">
                <span className="text-2xl">🏥</span>
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">MediQueue</h1>
                <p className="text-xs text-muted-foreground">Smart Hospital Queue</p>
              </div>
            </div>
            <Badge variant="secondary" className="hidden sm:flex gap-1">
              <Sparkles className="w-3 h-3" />
              AI-Powered
            </Badge>
          </div>

          {/* Hero Content */}
          <div className="max-w-3xl mx-auto text-center mb-12">
            <Badge variant="outline" className="mb-4">
              🚀 Reduce Wait Times by 60%
            </Badge>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground mb-4 leading-tight">
              Skip the Queue,{' '}
              <span className="text-gradient">Get Care Faster</span>
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Find nearby hospitals, check real-time wait times, and get a digital token 
              — all from your phone. No more standing in long queues.
            </p>
          </div>

          {/* Search Card */}
          <Card variant="elevated" className="max-w-2xl mx-auto overflow-hidden">
            <CardContent className="p-6">
              <div className="space-y-4">
                {/* Location Input */}
                <div className="relative">
                  <Input
                    icon={<MapPin className="w-5 h-5" />}
                    placeholder="Enter your city, area, or pincode"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="pr-24"
                  />
                  <Button
                    variant="ghost"
                    size="sm"
                    className="absolute right-1 top-1/2 -translate-y-1/2 text-xs"
                    onClick={handleGetLocation}
                  >
                    <MapPin className="w-4 h-4 mr-1" />
                    Use GPS
                  </Button>
                </div>

                {/* Hospital Type Selection */}
                <div className="grid grid-cols-3 gap-3">
                  <Button
                    variant={hospitalType === 'all' ? 'default' : 'outline'}
                    className="h-auto py-3 flex flex-col gap-1"
                    onClick={() => setHospitalType('all')}
                  >
                    <Search className="w-5 h-5" />
                    <span className="text-sm">All</span>
                  </Button>
                  <Button
                    variant={hospitalType === 'public' ? 'default' : 'outline'}
                    className="h-auto py-3 flex flex-col gap-1"
                    onClick={() => setHospitalType('public')}
                  >
                    <Building2 className="w-5 h-5" />
                    <span className="text-sm">Public</span>
                  </Button>
                  <Button
                    variant={hospitalType === 'private' ? 'default' : 'outline'}
                    className="h-auto py-3 flex flex-col gap-1"
                    onClick={() => setHospitalType('private')}
                  >
                    <Building className="w-5 h-5" />
                    <span className="text-sm">Private</span>
                  </Button>
                </div>

                {/* Search Button */}
                <Button 
                  className="w-full" 
                  size="xl" 
                  variant="hero"
                  onClick={handleSearch}
                >
                  <Search className="w-5 h-5" />
                  Find Hospitals Near Me
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Feature Pills */}
          <div className="flex flex-wrap justify-center gap-3 mt-8">
            <Badge variant="secondary" className="py-2 px-4">
              <Clock className="w-4 h-4 mr-1.5" />
              Real-time Wait Times
            </Badge>
            <Badge variant="secondary" className="py-2 px-4">
              <Users className="w-4 h-4 mr-1.5" />
              Live Queue Tracking
            </Badge>
            <Badge variant="secondary" className="py-2 px-4">
              <Shield className="w-4 h-4 mr-1.5" />
              Emergency Priority
            </Badge>
            <Badge variant="secondary" className="py-2 px-4">
              <Zap className="w-4 h-4 mr-1.5" />
              Digital Tokens
            </Badge>
          </div>
        </div>
      </section>

      {/* Results Section */}
      {showResults && (
        <section className="container mx-auto px-4 pb-16 animate-fade-in">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-xl font-semibold text-foreground">
                {filteredHospitals.length} Hospitals Found
              </h2>
              <p className="text-muted-foreground text-sm">
                {location || 'Near your location'}
              </p>
            </div>
            <Badge variant="outline">
              Sorted by distance
            </Badge>
          </div>

          <div className="grid gap-4">
            {filteredHospitals.map((hospital) => (
              <HospitalCard
                key={hospital.id}
                hospital={hospital}
                onClick={() => handleHospitalClick(hospital.id)}
              />
            ))}
          </div>

          {/* AI Recommendation */}
          <Card className="mt-6 border-primary/30 bg-primary/5">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-primary" />
              </div>
              <div className="flex-1">
                <p className="font-medium text-foreground">AI Recommendation</p>
                <p className="text-sm text-muted-foreground">
                  Based on current queue data, <span className="text-primary font-medium">Apollo Medical Center</span> has 
                  20 minutes less wait time than average.
                </p>
              </div>
            </CardContent>
          </Card>
        </section>
      )}
    </div>
  );
};

export default Index;
