import { useState } from 'react';
import { Header, PageHeader } from '@/components/Layout';
import { DoctorPanel, DoctorDashboardCard } from '@/components/DoctorPanel';
import { PatientQueue } from '@/components/PatientQueue';
import { mockDoctors, mockPatients } from '@/data/mockData';
import { Stethoscope } from 'lucide-react';
import { toast } from 'sonner';

export default function DoctorDashboard() {
  const [doctors, setDoctors] = useState(mockDoctors);
  const [patients, setPatients] = useState(mockPatients);
  
  // Simulate current doctor view (Dr. Rajesh Kapoor)
  const currentDoctor = doctors.find(d => d.id === '1');
  const myPatients = patients.filter(p => p.specialization === currentDoctor?.specialization);
  const nextPatient = myPatients.find(p => p.status === 'waiting');

  const handleCallNext = (doctorId?: string) => {
    if (nextPatient) {
      setPatients(prev => prev.map(p => 
        p.id === nextPatient.id 
          ? { ...p, status: 'called' as const }
          : p
      ));
      
      toast.success(
        <div>
          <p className="font-semibold">Calling Patient</p>
          <p className="text-sm">{nextPatient.name} - Token {nextPatient.tokenNumber}</p>
        </div>
      );
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-6">
        <PageHeader
          title="Doctor Dashboard"
          description="Manage your patients and queue"
          icon={<Stethoscope className="w-6 h-6" />}
        />

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Current Doctor Card */}
          <div className="lg:col-span-1">
            {currentDoctor && (
              <DoctorDashboardCard
                doctor={currentDoctor}
                nextPatient={nextPatient ? {
                  name: nextPatient.name,
                  caseType: nextPatient.caseType,
                  specialization: nextPatient.specialization,
                } : undefined}
                onCallNext={handleCallNext}
              />
            )}
          </div>

          {/* Patient Queue for this Doctor */}
          <div className="lg:col-span-2">
            <h2 className="text-lg font-semibold text-foreground mb-4">
              My Patients ({myPatients.length})
            </h2>
            <PatientQueue
              patients={myPatients}
              onCallPatient={handleCallNext}
              showActions
            />
          </div>
        </div>

        {/* All Doctors Status */}
        <div className="mt-8">
          <h2 className="text-lg font-semibold text-foreground mb-4">All Doctors Status</h2>
          <DoctorPanel doctors={doctors} />
        </div>
      </main>
    </div>
  );
}
