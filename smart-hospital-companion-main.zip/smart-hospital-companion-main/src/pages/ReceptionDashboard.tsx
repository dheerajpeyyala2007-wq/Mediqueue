import { useState } from 'react';
import { Header, PageHeader } from '@/components/Layout';
import { ReceptionCheckIn, QueueSummary } from '@/components/ReceptionCheckIn';
import { PatientQueue } from '@/components/PatientQueue';
import { mockPatients } from '@/data/mockData';
import { Patient } from '@/types/hospital';
import { ClipboardList } from 'lucide-react';

export default function ReceptionDashboard() {
  const [patients, setPatients] = useState<Patient[]>(mockPatients);

  const handleCheckIn = (patientData: {
    name: string;
    caseType: 'emergency' | 'normal';
    specialization: string;
  }) => {
    const tokenPrefix = patientData.caseType === 'emergency' ? 'E' : 'N';
    const tokenNumber = `${tokenPrefix}${String(patients.length + 1).padStart(3, '0')}`;
    
    const newPatient: Patient = {
      id: String(Date.now()),
      name: patientData.name,
      caseType: patientData.caseType,
      specialization: patientData.specialization,
      estimatedWaitTime: patientData.caseType === 'emergency' ? 10 : 30,
      queuePosition: patients.length + 1,
      status: 'waiting',
      checkInTime: new Date(),
      tokenNumber,
    };

    setPatients(prev => [...prev, newPatient]);
  };

  const emergencyCount = patients.filter(p => p.caseType === 'emergency' && p.status === 'waiting').length;
  const normalCount = patients.filter(p => p.caseType === 'normal' && p.status === 'waiting').length;

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-6">
        <PageHeader
          title="Reception Dashboard"
          description="Patient check-in and queue management"
          icon={<ClipboardList className="w-6 h-6" />}
        />

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Check-in Form */}
          <div className="lg:col-span-1 space-y-4">
            <ReceptionCheckIn onCheckIn={handleCheckIn} />
            <QueueSummary emergencyCount={emergencyCount} normalCount={normalCount} />
          </div>

          {/* Live Queue */}
          <div className="lg:col-span-2">
            <h2 className="text-lg font-semibold text-foreground mb-4">Live Queue</h2>
            <PatientQueue patients={patients.filter(p => p.status === 'waiting')} />
          </div>
        </div>
      </main>
    </div>
  );
}
