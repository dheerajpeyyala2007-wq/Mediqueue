import { Header, PageHeader } from '@/components/Layout';
import { 
  AdminStats, 
  HourlyPatientChart, 
  CaseTypeDistribution, 
  DoctorUtilizationChart,
  WeeklyTrendChart 
} from '@/components/AdminAnalytics';
import { DoctorPanel } from '@/components/DoctorPanel';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { mockDoctors } from '@/data/mockData';
import { 
  BarChart3, 
  UserPlus, 
  AlertTriangle, 
  Sparkles,
  Settings,
  Download 
} from 'lucide-react';
import { toast } from 'sonner';

export default function AdminDashboard() {
  const adminStats = {
    totalPatients: 156,
    avgWaitTime: 28,
    emergencyRatio: 15,
    doctorUtilization: 78,
  };

  const handleExportData = () => {
    toast.success('Report exported successfully');
  };

  const handleAddDoctor = () => {
    toast.info('Opening doctor management...');
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-6">
        <PageHeader
          title="Admin Dashboard"
          description="Hospital analytics and management"
          icon={<BarChart3 className="w-6 h-6" />}
          actions={
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={handleExportData}>
                <Download className="w-4 h-4 mr-1" />
                Export
              </Button>
              <Button variant="default" size="sm" onClick={handleAddDoctor}>
                <UserPlus className="w-4 h-4 mr-1" />
                Add Doctor
              </Button>
            </div>
          }
        />

        {/* Key Stats */}
        <AdminStats stats={adminStats} />

        {/* AI Alerts */}
        <div className="grid md:grid-cols-2 gap-4 mt-6">
          <Card className="border-warning/30 bg-warning/5">
            <CardContent className="p-4 flex items-start gap-3">
              <div className="w-10 h-10 rounded-full bg-warning/20 flex items-center justify-center flex-shrink-0">
                <AlertTriangle className="w-5 h-5 text-warning" />
              </div>
              <div>
                <p className="font-semibold text-foreground">Peak Hour Alert</p>
                <p className="text-sm text-muted-foreground">
                  Patient volume expected to increase 40% between 2-4 PM. 
                  Consider adding 2 more doctors.
                </p>
              </div>
            </CardContent>
          </Card>
          
          <Card className="border-primary/30 bg-primary/5">
            <CardContent className="p-4 flex items-start gap-3">
              <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                <Sparkles className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="font-semibold text-foreground">AI Recommendation</p>
                <p className="text-sm text-muted-foreground">
                  Dr. Mehta is overloaded. Suggest redistributing 3 patients 
                  to Dr. Reddy for optimal balance.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Charts Grid */}
        <div className="grid lg:grid-cols-2 gap-6 mt-6">
          <HourlyPatientChart />
          <CaseTypeDistribution />
        </div>

        <div className="grid lg:grid-cols-2 gap-6 mt-6">
          <DoctorUtilizationChart />
          <WeeklyTrendChart />
        </div>

        {/* Doctor Management */}
        <div className="mt-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-foreground">Staff Management</h2>
            <Button variant="ghost" size="sm">
              <Settings className="w-4 h-4 mr-1" />
              Manage
            </Button>
          </div>
          <DoctorPanel doctors={mockDoctors} />
        </div>
      </main>
    </div>
  );
}
