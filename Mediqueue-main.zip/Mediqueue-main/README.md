# Mediqueue
This project introduces an AI-powered hospital queue and appointment management system that dynamically prioritizes patients and predicts waiting time in real time. It reduces delays, improves emergency response, and optimizes doctor workload for better healthcare delivery
